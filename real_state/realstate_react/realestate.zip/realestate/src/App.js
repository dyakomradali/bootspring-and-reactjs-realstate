import { BrowserRouter, Routes, Route } from "react-router-dom";
import Location from "./Components/Location";
import Category from "./Components/Category";
import Property from "./Components/Property";
import ResponsiveAppBar from "./Components/nav";
import Home from "./Components/Home";
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <ResponsiveAppBar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/location" element={<Location />} />
          <Route path="/category" element={<Category />} />
          <Route path="/Property" element={<Property />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
