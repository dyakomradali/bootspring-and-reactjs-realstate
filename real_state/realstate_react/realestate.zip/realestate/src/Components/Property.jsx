import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";

const Property = () => {
  const [properties, setProperties] = useState([]);
  const [location, setLocation] = useState([]);
  const [category, setCategory] = useState([]);
  const [formData, setFormData] = useState({
    room: "",
    price: "",
    description: "",
    image: "",
    lid: "",
    cid: "",
  });
  const [searchKeyword, setSearchKeyword] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const lo = await axios.get("http://localhost:8081/location/getAll");
      const ca = await axios.get("http://localhost:8081/category/getAll");
      const pro = await axios.get("http://localhost:8081/property/getAll");

      setLocation(lo.data);
      setCategory(ca.data);
      setProperties(pro.data);
    } catch (error) {
      console.log(error);
    }
  };

  const handleInputChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleAdd = async () => {
    try {
      const response = await axios.post(
        "http://localhost:8081/property/addproperty",
        {
          room: formData.room,
          price: formData.price,
          description: formData.description,
          image: formData.image,
          location: { lid: formData.lid },
          category: { cid: formData.cid },
        }
      );
      console.log(response.data);
      setFormData({
        room: "",
        price: "",
        description: "",
        image: "",
        lid: "",
        cid: "",
      });
      fetchData();
    } catch (error) {
      console.error("Error adding property:", error);
    }
  };

  const handleDelete = async (pid) => {
    try {
      await axios.delete(`http://localhost:8081/property/delete/${pid}`);
      setProperties(properties.filter((item) => item.pid !== pid));
    } catch (error) {
      console.error(`Error deleting property with ID ${pid}:`, error);
    }
  };

  const handleSearch = async () => {
    try {
      const response = await axios.get(
        `http://localhost:8081/property/searchByDescription?desc=${searchKeyword}`
      );
      setProperties(response.data);
    } catch (error) {
      console.error("Error searching properties:", error);
    }
  };

  return (
    <div className="container">
      <h3 className="text-center">Property Details</h3>
      <form className="mt-4">
        {/* Form inputs */}
        <div className="mb-3 row">
          <div className="col">
            <label htmlFor="room" className="form-label">
              Number of Rooms:
            </label>
            <input
              type="number"
              className="form-control"
              id="room"
              name="room"
              onChange={handleInputChange}
              value={formData.room}
            />
          </div>
          <div className="col">
            <label htmlFor="price" className="form-label">
              Price:
            </label>
            <input
              type="number"
              className="form-control"
              id="price"
              name="price"
              onChange={handleInputChange}
              value={formData.price}
            />
          </div>
        </div>

        <div className="mb-3">
          <label htmlFor="description" className="form-label">
            Description:
          </label>
          <input
            type="text"
            className="form-control"
            id="description"
            name="description"
            onChange={handleInputChange}
            value={formData.description}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="image" className="form-label">
            Image URL:
          </label>
          <input
            type="text"
            className="form-control"
            id="image"
            name="image"
            onChange={handleInputChange}
            value={formData.image}
          />
        </div>

        <div className="mb-3">
          <label htmlFor="location" className="form-label">
            Location:
          </label>
          <select
            className="form-select"
            id="location"
            name="lid"
            onChange={handleInputChange}
            value={formData.lid}
          >
            <option value="">Select Location</option>
            {location.map((lo) => (
              <option key={lo.lid} value={lo.lid}>
                {lo.city}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label htmlFor="category" className="form-label">
            Category:
          </label>
          <select
            className="form-select"
            id="category"
            onChange={handleInputChange}
            name="cid"
            value={formData.cid}
          >
            <option value="">Select Category</option>
            {category.map((ca) => (
              <option key={ca.cid} value={ca.cid}>
                {ca.type}
              </option>
            ))}
          </select>
        </div>

        <div className="text-center">
          <button type="button" className="btn btn-primary" onClick={handleAdd}>
            Submit
          </button>
        </div>
      </form>

      {/* Search input */}
      <div className="mb-3">
        <label htmlFor="searchKeyword" className="form-label">
          Search by Description:
        </label>
        <input
          type="text"
          className="form-control"
          id="searchKeyword"
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
        />
      </div>
      <button className="btn btn-primary" onClick={handleSearch}>
        Search
      </button>

      {/* Properties */}
      <div className="row row-cols-1 row-cols-md-4 g-4 mt-4">
        {properties.map((prop) => (
          <div key={prop.pid} className="col">
            <div className="card h-100">
              <img src={prop.image} className="card-img-top" alt="Property" />
              <div className="card-body">
                <h5 className="card-title">{prop.room} Rooms</h5>
                <p className="card-text">Price: ${prop.price}</p>
                <p className="card-text">{prop.description}</p>
                <p className="card-text">Location: {prop.location.city}</p>
                <p className="card-text">Category: {prop.category.type}</p>
              </div>
              <div className="card-footer">
                <button
                  className="btn btn-danger"
                  onClick={() => handleDelete(prop.pid)}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Property;
