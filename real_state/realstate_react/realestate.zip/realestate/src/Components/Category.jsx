import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from 'axios';

const Category = () => {
  const [categories, setCategories] = useState([]);
  const [formData, setFormData] = useState({ type: '' });
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  useEffect(() => {
    fetchData(currentPage);
  }, [currentPage]);

  const fetchData = async (page) => {
    try {
      const response = await axios.get(`http://localhost:8081/category/getAllPaginated`, {
        params: { page: page, size: 5 }
      });
      setCategories(response.data.content);
      setTotalPages(response.data.totalPages);
    } catch (error) {
      console.log(error);
    }
  };

  const handleInputChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleAdd = async () => {
    try {
      await axios.post('http://localhost:8081/category/add', formData);
      fetchData(currentPage);
      setFormData({ type: '' });
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (cid) => {
    console.log(cid);
    try {
      await axios.delete(`http://localhost:8081/category/delete/${cid}`);
      fetchData(currentPage);
    } catch (error) {
      console.error(error);
    }
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <div className="container mt-4">
      <h3 className="d-flex justify-content-center">Category</h3>
      <br />
      <form className="mb-4">
        <div className="form-group">
          <label htmlFor="type">Category Type</label>
          <input
            type="text"
            className="form-control"
            id="type"
            name="type"
            value={formData.type}
            onChange={handleInputChange}
          />
        </div>
        <button
          type="button"
          className="btn btn-primary mt-2"
          onClick={handleAdd}
        >
          Add Category
        </button>
      </form>
      <table className="table table-bordered">
        <thead className="thead-light">
          <tr>
            <th>ID</th>
            <th>Type</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {categories.map((category) => (
            <tr key={category.cid}>
              <td>{category.cid}</td>
              <td>{category.type}</td>
              <td>
                <button
                  className="btn btn-danger"
                  onClick={() => handleDelete(category.cid)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="d-flex justify-content-center">
        <nav>
          <ul className="pagination">
            {[...Array(totalPages).keys()].map((page) => (
              <li key={page} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                <button className="page-link" onClick={() => handlePageChange(page)}>
                  {page + 1}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default Category;
