import React, { Component } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Location from './Location';
import Category from './Category';
import Property from './Property';


class RouterPage extends Component {
  render() {
    return (
      <div>
        <BrowserRouter>
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route exact path="/location" element={<Location />} />
            <Route exact path="/category" element={<Category />} />
            <Route exact path="/property" element={<Property />} />
          </Routes>
        </BrowserRouter>
      </div>
    );
  }
}

export default RouterPage;
