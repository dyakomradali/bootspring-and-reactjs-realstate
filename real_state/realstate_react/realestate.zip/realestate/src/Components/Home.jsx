import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Carousel from 'react-bootstrap/Carousel';

const Home = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  useEffect(() => {
    fetchData();
  }, [currentPage]);

  const fetchData = async () => {
    try {
      const response = await axios.get(`http://localhost:8081/property/getAllPaginated?page=${currentPage}&size=8`);
      setProperties(response.data.content);
      setTotalPages(response.data.totalPages);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching properties:', error);
      setLoading(false);
    }
  };

  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  return (
    <div className="container">
      {/* Carousel */}
      <Carousel fade className="mb-4">
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg?auto=compress&cs=tinysrgb&w=750&h=500&dpr=2"
            alt="Second slide"
          />
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg?auto=compress&cs=tinysrgb&w=750&h=500&dpr=2"
            alt="Second slide"
          />
        </Carousel.Item>
      </Carousel>

      {/* Loader */}
      {loading && (
        <div className="text-center">
          <div className="spinner-grow text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          {/* Add more spinner-grow elements for different colors if needed */}
        </div>
      )}

      {/* Properties */}
      <h3 className="text-center">Properties</h3>
      <div className="row row-cols-1 row-cols-md-4 g-4 mt-4">
        {properties.map((property) => (
          <div key={property.pid} className="col">
            <div className="card h-100">
              <img src={property.image} className="card-img-top" alt="Property" />
              <div className="card-body">
                <h5 className="card-title">{property.room} Rooms</h5>
                <p className="card-text">Price: ${property.price}</p>
                <p className="card-text">{property.description}</p>
                <p className="card-text">Location: {property.location.city}</p>
                <p className="card-text">Category: {property.category.type}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
<br />
      {/* Pagination */}
      <div className="d-flex justify-content-center">
        <nav>
          <ul className="pagination">
            {[...Array(totalPages).keys()].map((page) => (
              <li key={page} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                <button className="page-link" onClick={() => handlePageChange(page)}>
                  {page + 1}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {/* Footer */}
      <footer className="text-center mt-4">
        <p>&copy; 2024  Real Estate Project</p>
      </footer>
    </div>
  );
};

export default Home;
